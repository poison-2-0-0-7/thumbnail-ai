"""Deterministic Module 6 prompt-compilation engine.

This module compiles a Module 5 :class:`RedesignSpecification` into a
:class:`PromptPackage` ready for an image-generation stage (Module 7). It
is a *compiler*, not a reasoning system: every field of the output is a
fixed-template string, a direct pass-through, or a deterministic
arithmetic/rule-table transform of fields the specification already
contains.

Module 6 never:
    - calls Gemini, GPT, Claude, Ollama, or any other AI/LLM service.
    - opens image pixels or performs any computer-vision analysis.
    - reinterprets, second-guesses, or overrides a Module 5 decision.
    - invents creative content (new copy, new colors, new subjects).
    - depends on Modules 1-4 — its only input type is
      :class:`RedesignSpecification`.

Given identical input, :func:`compile_prompt_package` always produces an
identical :class:`PromptPackage` (aside from the bookkeeping
``duration_seconds`` and ``generated_at`` fields, which record wall-clock
timing exactly as every prior module's report does).

Prompt packages are stored as atomic JSON files in
``data/prompt_packages``.
"""

from __future__ import annotations

import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

_MODULES_DIR = Path(__file__).resolve().parent
if str(_MODULES_DIR) not in sys.path:
    sys.path.insert(0, str(_MODULES_DIR))

from loguru import logger

from config import (
    BASE_NEGATIVE_PROMPT_TERMS,
    BASE_QUALITY_TAGS,
    BASE_RENDERING_CONSTRAINTS,
    DEFAULT_ASPECT_RATIO,
    DEFAULT_GENERATION_HEIGHT,
    DEFAULT_GENERATION_WIDTH,
    DEFAULT_GUIDANCE_SCALE,
    DEFAULT_INFERENCE_STEPS,
    DEFAULT_MIN_RESOLUTION_PX,
    DEFAULT_MODEL_NAME,
    DEFAULT_NEGATIVE_PROMPT_WEIGHT,
    DEFAULT_PROMPT_PACKAGE_DIR,
    DEFAULT_SAMPLER,
    DEFAULT_STYLE_PRESET,
    LOG_DIR,
    MODULE6_LOG_PATH,
    PROMPT_PACKAGE_FILENAME_TEMPLATE,
    SAFETY_CONSTRAINTS,
    SEED_HASH_MODULUS,
    ZONE_THIRD_THRESHOLD,
)
from models import (
    BoundingBox,
    ColorDirection,
    GenerationParameters,
    LayoutDirection,
    ModelSettings,
    ObjectDirective,
    PromptPackage,
    QualityParameters,
    RedesignSpecification,
    SubjectTreatment,
    TextOverlaySpec,
)


_LOG_FORMAT: str = "{time:YYYY-MM-DD HH:mm:ss} | {level:<8} | {name} | {message}"


def _configure_logger() -> None:
    """Attach the Module 6 rotating Loguru sink."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger.add(
        str(MODULE6_LOG_PATH),
        rotation="10 MB",
        retention="30 days",
        format=_LOG_FORMAT,
        level="DEBUG",
        enqueue=True,
    )


_configure_logger()


class PromptCompilerError(Exception):
    """Base exception for Module 6 failures."""


class InvalidRedesignSpecError(PromptCompilerError):
    """Raised when a Module 5 spec cannot support deterministic compilation."""


class PromptPackageCacheError(PromptCompilerError):
    """Raised when a prompt package cache cannot be written."""


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _zone_label(bbox: Optional[BoundingBox]) -> str:
    """Describe a bbox's center as a coarse 3x3 grid zone (e.g. ``"top-left"``).

    Returns ``"center"`` when ``bbox`` is ``None``, keeping every
    instruction compiler well-defined even when a specification omits a
    target zone.
    """
    if bbox is None:
        return "center"

    center_x = (bbox.x_min + bbox.x_max) / 2
    center_y = (bbox.y_min + bbox.y_max) / 2
    high_threshold = 1 - ZONE_THIRD_THRESHOLD

    if center_x < ZONE_THIRD_THRESHOLD:
        horizontal = "left"
    elif center_x > high_threshold:
        horizontal = "right"
    else:
        horizontal = "center"

    if center_y < ZONE_THIRD_THRESHOLD:
        vertical = "top"
    elif center_y > high_threshold:
        vertical = "bottom"
    else:
        vertical = "middle"

    if horizontal == "center" and vertical == "middle":
        return "center"
    if vertical == "middle":
        return horizontal
    if horizontal == "center":
        return vertical
    return f"{vertical}-{horizontal}"


# ---------------------------------------------------------------------------
# Instruction compilers
# ---------------------------------------------------------------------------


def _compile_subject_instructions(subject: SubjectTreatment) -> str:
    """Compile subject placement/crop guidance from a ``SubjectTreatment``."""
    if not subject.has_subject:
        return (
            "No primary subject was specified; compose the thumbnail "
            "without inventing a dominant foreground figure."
        )

    zone = _zone_label(subject.target_bbox)
    sentence = (
        f"Place the primary subject in the {zone} of the frame, "
        f"matching the source position label '{subject.target_position_label}'."
    )
    if subject.crop_tighter:
        sentence += " Crop tighter around the subject so it occupies a larger share of the frame."
    return sentence


def _compile_background_instructions(layout: LayoutDirection) -> str:
    """Compile background/negative-space guidance from a ``LayoutDirection``."""
    sentence = (
        f"Maintain approximately {layout.target_negative_space_ratio:.0%} "
        "negative space in the background."
    )
    if layout.target_clutter_score <= 0.3:
        sentence += " Keep the background minimal and uncluttered."
    elif layout.target_clutter_score <= 0.6:
        sentence += " Keep the background moderately simple with limited competing elements."
    else:
        sentence += " Background detail is acceptable within the configured clutter target."
    return sentence


def _compile_typography_instructions(text_overlay: TextOverlaySpec) -> str:
    """Compile placement-only text guidance; never invents new copy."""
    if not text_overlay.include_text:
        return "Do not render any text overlay on the thumbnail."

    sentence = "Preserve existing text placement; do not invent new copy or wording."
    if text_overlay.placement_zone is not None:
        zone = _zone_label(text_overlay.placement_zone)
        sentence += f" Reserve the {zone} region of the frame for text."
    if text_overlay.avoid_zones:
        zones = ", ".join(_zone_label(zone) for zone in text_overlay.avoid_zones)
        sentence += f" Avoid placing text over the following region(s): {zones}."
    return sentence


def _compile_composition_instructions(layout: LayoutDirection) -> str:
    """Compile focal-point and composition-target guidance."""
    zone = _zone_label(layout.focal_zone)
    return (
        f"Anchor the composition's focal point in the {zone} of the frame, "
        f"targeting a clutter score of {layout.target_clutter_score:.2f} and "
        f"a negative-space ratio of {layout.target_negative_space_ratio:.2f}."
    )


def _compile_lighting_instructions(color: ColorDirection) -> str:
    """Compile lighting guidance from brightness/contrast targets."""
    if color.target_brightness >= 0.6:
        brightness_desc = "bright, well-lit"
    elif color.target_brightness <= 0.4:
        brightness_desc = "moody, low-key"
    else:
        brightness_desc = "balanced"

    if color.target_contrast >= 0.6:
        contrast_desc = "high-contrast"
    elif color.target_contrast <= 0.4:
        contrast_desc = "soft-contrast"
    else:
        contrast_desc = "moderate-contrast"

    return (
        f"Use {brightness_desc} lighting with a {contrast_desc} look "
        f"(target brightness={color.target_brightness:.2f}, "
        f"target contrast={color.target_contrast:.2f})."
    )


def _compile_color_instructions(color: ColorDirection) -> str:
    """Compile color-palette guidance from saturation/temperature targets."""
    if color.target_saturation >= 0.6:
        saturation_desc = "vivid, highly saturated"
    elif color.target_saturation <= 0.4:
        saturation_desc = "muted, desaturated"
    else:
        saturation_desc = "moderately saturated"

    return (
        f"Render {saturation_desc} colors with a {color.warm_or_cool} color "
        f"temperature (target saturation={color.target_saturation:.2f})."
    )


def _compile_object_placement(directives: list[ObjectDirective]) -> list[str]:
    """Compile one placement line per object directive, in spec order."""
    return [f"{directive.label}: {directive.action}" for directive in directives]


def _compile_rendering_constraints(spec: RedesignSpecification) -> list[str]:
    """Compile the fixed rendering-constraint list, extended per-spec."""
    constraints = list(BASE_RENDERING_CONSTRAINTS)
    if spec.elements_to_preserve:
        preserved = ", ".join(spec.elements_to_preserve)
        constraints.append(f"Preserve the following elements exactly: {preserved}.")
    if not spec.text_overlay.include_text:
        constraints.append("Do not add any text to the rendered image.")
    return constraints


def _compile_positive_prompt(
    subject_instructions: str,
    background_instructions: str,
    composition_instructions: str,
    lighting_instructions: str,
    color_instructions: str,
    typography_instructions: str,
    elements_to_preserve: list[str],
) -> str:
    """Assemble the positive prompt from every instruction segment, in a
    fixed order, so identical inputs always produce an identical string."""
    segments = [
        subject_instructions,
        background_instructions,
        composition_instructions,
        lighting_instructions,
        color_instructions,
        typography_instructions,
    ]
    if elements_to_preserve:
        segments.append("Preserve: " + ", ".join(elements_to_preserve) + ".")
    return " ".join(segments)


def _compile_negative_prompt(directives: list[ObjectDirective]) -> str:
    """Assemble the negative prompt from the fixed base terms plus any
    objects Module 5 flagged for removal."""
    terms = list(BASE_NEGATIVE_PROMPT_TERMS)
    removed_labels = [directive.label for directive in directives if directive.action == "remove"]
    terms.extend(f"no {label}" for label in removed_labels)
    return ", ".join(terms)


# ---------------------------------------------------------------------------
# Parameter compilers
# ---------------------------------------------------------------------------


def _derive_seed(video_id: str) -> int:
    """Derive a fully deterministic seed from ``video_id``.

    Uses SHA-256 rather than Python's built-in ``hash()`` because
    ``hash()`` is randomized per-process for strings (``PYTHONHASHSEED``)
    and would violate Module 6's zero-randomness requirement.
    """
    digest = hashlib.sha256(video_id.encode("utf-8")).hexdigest()
    return int(digest, 16) % SEED_HASH_MODULUS


def _compile_generation_parameters(video_id: str) -> GenerationParameters:
    """Compile deterministic generation parameters for ``video_id``."""
    return GenerationParameters(
        width=DEFAULT_GENERATION_WIDTH,
        height=DEFAULT_GENERATION_HEIGHT,
        aspect_ratio=DEFAULT_ASPECT_RATIO,
        seed=_derive_seed(video_id),
        guidance_scale=DEFAULT_GUIDANCE_SCALE,
        inference_steps=DEFAULT_INFERENCE_STEPS,
        sampler=DEFAULT_SAMPLER,
    )


def _compile_quality_parameters(subject: SubjectTreatment) -> QualityParameters:
    """Compile deterministic quality parameters; upscaling follows the
    subject's tighter-crop flag rather than any random choice."""
    return QualityParameters(
        quality_tags=list(BASE_QUALITY_TAGS),
        min_resolution_px=DEFAULT_MIN_RESOLUTION_PX,
        upscale_requested=subject.crop_tighter,
    )


def _compile_model_settings(color: ColorDirection) -> ModelSettings:
    """Compile deterministic model settings; the style preset follows the
    spec's color temperature directive rather than any free choice."""
    if color.warm_or_cool == "neutral":
        style_preset = DEFAULT_STYLE_PRESET
    else:
        style_preset = f"{color.warm_or_cool}-{DEFAULT_STYLE_PRESET}"
    return ModelSettings(
        model_name=DEFAULT_MODEL_NAME,
        style_preset=style_preset,
        negative_prompt_weight=DEFAULT_NEGATIVE_PROMPT_WEIGHT,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def compile_prompt_package(spec: RedesignSpecification) -> PromptPackage:
    """Deterministically compile a Module 5 spec into a ``PromptPackage``.

    Raises:
        InvalidRedesignSpecError: if ``spec.status == "error"``, in which
            case there is no usable redesign guidance to compile.
    """
    if spec.status == "error":
        raise InvalidRedesignSpecError(
            "RedesignSpecification must have non-error status to compile a prompt package"
        )

    started_at = time.monotonic()

    subject_instructions = _compile_subject_instructions(spec.subject_treatment)
    background_instructions = _compile_background_instructions(spec.layout_direction)
    typography_instructions = _compile_typography_instructions(spec.text_overlay)
    composition_instructions = _compile_composition_instructions(spec.layout_direction)
    lighting_instructions = _compile_lighting_instructions(spec.color_direction)
    color_instructions = _compile_color_instructions(spec.color_direction)
    object_placement = _compile_object_placement(spec.object_directives)
    rendering_constraints = _compile_rendering_constraints(spec)

    positive_prompt = _compile_positive_prompt(
        subject_instructions,
        background_instructions,
        composition_instructions,
        lighting_instructions,
        color_instructions,
        typography_instructions,
        spec.elements_to_preserve,
    )
    negative_prompt = _compile_negative_prompt(spec.object_directives)

    package = PromptPackage(
        video_id=spec.video_id,
        positive_prompt=positive_prompt,
        negative_prompt=negative_prompt,
        subject_instructions=subject_instructions,
        background_instructions=background_instructions,
        typography_instructions=typography_instructions,
        composition_instructions=composition_instructions,
        lighting_instructions=lighting_instructions,
        color_instructions=color_instructions,
        object_placement=object_placement,
        rendering_constraints=rendering_constraints,
        safety_constraints=list(SAFETY_CONSTRAINTS),
        generation_parameters=_compile_generation_parameters(spec.video_id),
        quality_parameters=_compile_quality_parameters(spec.subject_treatment),
        model_settings=_compile_model_settings(spec.color_direction),
        duration_seconds=time.monotonic() - started_at,
        generated_at=datetime.now(timezone.utc).isoformat(),
    )
    logger.info(
        "Prompt package compiled for video_id={id} ({dur:.4f}s)",
        id=spec.video_id,
        dur=package.duration_seconds,
    )
    return package


def _prompt_package_path(video_id: str, package_dir: Path) -> Path:
    """Return the canonical JSON path for a prompt package."""
    return package_dir / PROMPT_PACKAGE_FILENAME_TEMPLATE.format(video_id=video_id)


def save_prompt_package(
    package: PromptPackage,
    package_dir: Path = DEFAULT_PROMPT_PACKAGE_DIR,
) -> None:
    """Persist a prompt package atomically as JSON."""
    target = _prompt_package_path(package.video_id, package_dir)
    tmp = target.with_suffix(".tmp")
    try:
        package_dir.mkdir(parents=True, exist_ok=True)
        tmp.write_text(package.model_dump_json(indent=2), encoding="utf-8")
        tmp.replace(target)
        logger.debug(
            "Saved prompt package for video_id={id} -> {path}", id=package.video_id, path=target
        )
    except OSError as exc:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        logger.error(
            "Failed to save prompt package for video_id={id}: {exc}", id=package.video_id, exc=exc
        )
        raise PromptPackageCacheError(
            f"Could not write prompt package to {target}: {exc}"
        ) from exc


def load_cached_prompt_package(
    video_id: str,
    package_dir: Path = DEFAULT_PROMPT_PACKAGE_DIR,
) -> Optional[PromptPackage]:
    """Load a valid cached prompt package, or return ``None`` on a cache miss."""
    path = _prompt_package_path(video_id, package_dir)
    if not path.exists():
        logger.debug("Prompt package cache miss for video_id={id}", id=video_id)
        return None
    try:
        cached = PromptPackage.model_validate_json(path.read_text(encoding="utf-8"))
        logger.debug("Prompt package cache hit for video_id={id}: {path}", id=video_id, path=path)
        return cached
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        logger.warning(
            "Cached prompt package for video_id={id} is unreadable ({reason}) — treating as cache miss",
            id=video_id,
            reason=exc,
        )
        return None
