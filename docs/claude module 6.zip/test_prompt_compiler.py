"""Pure unit tests for Module 6's deterministic prompt-compilation engine."""

from __future__ import annotations

from pathlib import Path
import sys

import pytest

_MODULES_DIR = Path(__file__).resolve().parent.parent / "modules"
if str(_MODULES_DIR) not in sys.path:
    sys.path.insert(0, str(_MODULES_DIR))

from config import (  # noqa: E402
    BASE_NEGATIVE_PROMPT_TERMS,
    BASE_QUALITY_TAGS,
    BASE_RENDERING_CONSTRAINTS,
    SAFETY_CONSTRAINTS,
)
from models import (  # noqa: E402
    BoundingBox,
    ColorDirection,
    LayoutDirection,
    ObjectDirective,
    RedesignSpecification,
    SubjectTreatment,
    TextOverlaySpec,
)
from prompt_compiler import (  # noqa: E402
    InvalidRedesignSpecError,
    PromptPackageCacheError,
    _compile_background_instructions,
    _compile_color_instructions,
    _compile_composition_instructions,
    _compile_lighting_instructions,
    _compile_negative_prompt,
    _compile_object_placement,
    _compile_positive_prompt,
    _compile_rendering_constraints,
    _compile_subject_instructions,
    _compile_typography_instructions,
    _derive_seed,
    _zone_label,
    compile_prompt_package,
    load_cached_prompt_package,
    save_prompt_package,
)

VALID_VIDEO_ID = "abcdEFGH123"
LEFT_TOP_BOX = BoundingBox(x_min=0.0, y_min=0.0, x_max=0.20, y_max=0.20)
CENTER_BOX = BoundingBox(x_min=0.40, y_min=0.40, x_max=0.60, y_max=0.60)
RIGHT_BOTTOM_BOX = BoundingBox(x_min=0.80, y_min=0.80, x_max=1.0, y_max=1.0)
TOP_BOX = BoundingBox(x_min=0.40, y_min=0.0, x_max=0.60, y_max=0.10)
RIGHT_BOX = BoundingBox(x_min=0.85, y_min=0.40, x_max=0.99, y_max=0.60)


def _spec(**updates: object) -> RedesignSpecification:
    values: dict[str, object] = {
        "video_id": VALID_VIDEO_ID,
        "source_thumbnail_path": "data/thumbnails/abcdEFGH123.jpg",
        "color_direction": ColorDirection(
            target_brightness=0.5, target_contrast=0.5, target_saturation=0.5, warm_or_cool="neutral"
        ),
        "subject_treatment": SubjectTreatment(has_subject=False),
        "text_overlay": TextOverlaySpec(),
        "layout_direction": LayoutDirection(),
        "object_directives": [],
        "elements_to_preserve": [],
        "overall_rationale": "test rationale",
        "source_ctr_potential_score": 0.6,
        "source_curiosity_gap_score": 0.4,
        "source_content_mismatch_detected": False,
        "generated_at": "2026-01-01T00:00:00+00:00",
    }
    values.update(updates)
    return RedesignSpecification(**values)


# ---------------------------------------------------------------------------
# _zone_label
# ---------------------------------------------------------------------------


class TestZoneLabel:
    def test_none_bbox_is_center(self) -> None:
        assert _zone_label(None) == "center"

    def test_center_bbox_is_center(self) -> None:
        assert _zone_label(CENTER_BOX) == "center"

    def test_top_left_bbox(self) -> None:
        assert _zone_label(LEFT_TOP_BOX) == "top-left"

    def test_bottom_right_bbox(self) -> None:
        assert _zone_label(RIGHT_BOTTOM_BOX) == "bottom-right"

    def test_pure_top_bbox(self) -> None:
        assert _zone_label(TOP_BOX) == "top"

    def test_pure_right_bbox(self) -> None:
        assert _zone_label(RIGHT_BOX) == "right"


# ---------------------------------------------------------------------------
# Instruction compilers
# ---------------------------------------------------------------------------


class TestCompileSubjectInstructions:
    def test_no_subject_does_not_invent_one(self) -> None:
        result = _compile_subject_instructions(SubjectTreatment(has_subject=False))
        assert "No primary subject" in result

    def test_subject_placement_mentions_zone_and_label(self) -> None:
        result = _compile_subject_instructions(
            SubjectTreatment(has_subject=True, target_bbox=LEFT_TOP_BOX, target_position_label="left-third")
        )
        assert "top-left" in result
        assert "left-third" in result
        assert "Crop tighter" not in result

    def test_crop_tighter_flag_is_mentioned(self) -> None:
        result = _compile_subject_instructions(
            SubjectTreatment(has_subject=True, target_bbox=CENTER_BOX, crop_tighter=True)
        )
        assert "Crop tighter" in result


class TestCompileBackgroundInstructions:
    @pytest.mark.parametrize(
        "clutter,expected_phrase",
        [
            (0.1, "minimal and uncluttered"),
            (0.5, "moderately simple"),
            (0.9, "acceptable within the configured clutter target"),
        ],
    )
    def test_clutter_tiers(self, clutter: float, expected_phrase: str) -> None:
        result = _compile_background_instructions(
            LayoutDirection(target_negative_space_ratio=0.3, target_clutter_score=clutter)
        )
        assert expected_phrase in result

    def test_negative_space_percentage_is_formatted(self) -> None:
        result = _compile_background_instructions(
            LayoutDirection(target_negative_space_ratio=0.25, target_clutter_score=0.1)
        )
        assert "25%" in result


class TestCompileTypographyInstructions:
    def test_no_text_requested_forbids_rendering_text(self) -> None:
        result = _compile_typography_instructions(TextOverlaySpec(include_text=False))
        assert "Do not render any text" in result

    def test_placement_zone_and_avoid_zones_are_described(self) -> None:
        result = _compile_typography_instructions(
            TextOverlaySpec(
                include_text=True,
                placement_zone=TOP_BOX,
                avoid_zones=[CENTER_BOX],
            )
        )
        assert "do not invent new copy" in result
        assert "top" in result
        assert "Avoid placing text" in result

    def test_never_invents_copy_even_when_preserved(self) -> None:
        result = _compile_typography_instructions(TextOverlaySpec(include_text=True))
        assert "invent new copy" in result


class TestCompileCompositionInstructions:
    def test_mentions_focal_zone_and_targets(self) -> None:
        result = _compile_composition_instructions(
            LayoutDirection(focal_zone=RIGHT_BOX, target_clutter_score=0.42, target_negative_space_ratio=0.33)
        )
        assert "right" in result
        assert "0.42" in result
        assert "0.33" in result

    def test_no_focal_zone_defaults_to_center(self) -> None:
        result = _compile_composition_instructions(LayoutDirection())
        assert "center" in result


class TestCompileLightingInstructions:
    @pytest.mark.parametrize(
        "brightness,expected", [(0.8, "bright, well-lit"), (0.2, "moody, low-key"), (0.5, "balanced")]
    )
    def test_brightness_tiers(self, brightness: float, expected: str) -> None:
        result = _compile_lighting_instructions(ColorDirection(target_brightness=brightness))
        assert expected in result

    @pytest.mark.parametrize(
        "contrast,expected", [(0.8, "high-contrast"), (0.2, "soft-contrast"), (0.5, "moderate-contrast")]
    )
    def test_contrast_tiers(self, contrast: float, expected: str) -> None:
        result = _compile_lighting_instructions(ColorDirection(target_contrast=contrast))
        assert expected in result


class TestCompileColorInstructions:
    @pytest.mark.parametrize(
        "saturation,expected",
        [(0.8, "vivid, highly saturated"), (0.2, "muted, desaturated"), (0.5, "moderately saturated")],
    )
    def test_saturation_tiers(self, saturation: float, expected: str) -> None:
        result = _compile_color_instructions(ColorDirection(target_saturation=saturation))
        assert expected in result

    def test_temperature_is_included(self) -> None:
        result = _compile_color_instructions(ColorDirection(warm_or_cool="warm"))
        assert "warm color" in result


class TestCompileObjectPlacement:
    def test_empty_directives_yield_empty_list(self) -> None:
        assert _compile_object_placement([]) == []

    def test_directives_render_label_and_action_in_order(self) -> None:
        directives = [
            ObjectDirective(label="person", action="preserve"),
            ObjectDirective(label="bowl", action="remove"),
        ]
        assert _compile_object_placement(directives) == ["person: preserve", "bowl: remove"]


class TestCompileRenderingConstraints:
    def test_base_constraints_always_present(self) -> None:
        result = _compile_rendering_constraints(_spec())
        for constraint in BASE_RENDERING_CONSTRAINTS:
            assert constraint in result

    def test_preserved_elements_are_listed(self) -> None:
        result = _compile_rendering_constraints(_spec(elements_to_preserve=["faces", "logo"]))
        assert any("faces, logo" in item for item in result)

    def test_no_text_overlay_adds_no_text_constraint(self) -> None:
        result = _compile_rendering_constraints(_spec(text_overlay=TextOverlaySpec(include_text=False)))
        assert any("Do not add any text" in item for item in result)


class TestCompilePositiveAndNegativePrompt:
    def test_positive_prompt_includes_every_segment_in_order(self) -> None:
        result = _compile_positive_prompt("A", "B", "C", "D", "E", "F", [])
        assert result == "A B C D E F"

    def test_positive_prompt_appends_preserved_elements(self) -> None:
        result = _compile_positive_prompt("A", "B", "C", "D", "E", "F", ["logo", "text"])
        assert result.endswith("Preserve: logo, text.")

    def test_negative_prompt_contains_base_terms(self) -> None:
        result = _compile_negative_prompt([])
        for term in BASE_NEGATIVE_PROMPT_TERMS:
            assert term in result

    def test_negative_prompt_adds_removed_object_labels(self) -> None:
        directives = [ObjectDirective(label="bowl", action="remove"), ObjectDirective(label="person", action="preserve")]
        result = _compile_negative_prompt(directives)
        assert "no bowl" in result
        assert "no person" not in result


# ---------------------------------------------------------------------------
# _derive_seed
# ---------------------------------------------------------------------------


class TestDeriveSeed:
    def test_seed_is_deterministic_across_calls(self) -> None:
        assert _derive_seed(VALID_VIDEO_ID) == _derive_seed(VALID_VIDEO_ID)

    def test_different_ids_produce_different_seeds(self) -> None:
        assert _derive_seed(VALID_VIDEO_ID) != _derive_seed("zzzzzzzzzzz")

    def test_seed_is_nonnegative_int(self) -> None:
        seed = _derive_seed(VALID_VIDEO_ID)
        assert isinstance(seed, int)
        assert seed >= 0


# ---------------------------------------------------------------------------
# compile_prompt_package
# ---------------------------------------------------------------------------


class TestCompilePromptPackage:
    def test_builds_complete_package(self) -> None:
        result = compile_prompt_package(_spec())
        assert result.video_id == VALID_VIDEO_ID
        assert result.status == "success"
        assert result.safety_constraints == list(SAFETY_CONSTRAINTS)
        assert result.quality_parameters.quality_tags == list(BASE_QUALITY_TAGS)

    def test_rejects_error_status_spec(self) -> None:
        with pytest.raises(InvalidRedesignSpecError):
            compile_prompt_package(_spec(status="error", error_message="boom"))

    def test_output_is_deterministic_for_identical_input(self) -> None:
        first = compile_prompt_package(_spec())
        second = compile_prompt_package(_spec())
        assert first.positive_prompt == second.positive_prompt
        assert first.negative_prompt == second.negative_prompt
        assert first.generation_parameters.seed == second.generation_parameters.seed
        assert first.generation_parameters == second.generation_parameters
        assert first.quality_parameters == second.quality_parameters
        assert first.model_settings == second.model_settings
        assert first.object_placement == second.object_placement
        assert first.rendering_constraints == second.rendering_constraints

    def test_crop_tighter_requests_upscale(self) -> None:
        result = compile_prompt_package(
            _spec(subject_treatment=SubjectTreatment(has_subject=True, target_bbox=CENTER_BOX, crop_tighter=True))
        )
        assert result.quality_parameters.upscale_requested is True

    def test_warm_color_direction_sets_style_preset(self) -> None:
        result = compile_prompt_package(
            _spec(color_direction=ColorDirection(warm_or_cool="warm"))
        )
        assert result.model_settings.style_preset == "warm-photographic"

    def test_neutral_color_direction_uses_default_style_preset(self) -> None:
        result = compile_prompt_package(_spec(color_direction=ColorDirection(warm_or_cool="neutral")))
        assert result.model_settings.style_preset == "photographic"

    def test_never_invents_object_directives(self) -> None:
        directives = [ObjectDirective(label="phone", action="include")]
        result = compile_prompt_package(_spec(object_directives=directives))
        assert result.object_placement == ["phone: include"]


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


class TestPromptPackagePersistence:
    def test_save_and_load_round_trip(self, tmp_path: Path) -> None:
        package = compile_prompt_package(_spec())
        save_prompt_package(package, tmp_path)
        assert load_cached_prompt_package(VALID_VIDEO_ID, tmp_path) == package
        assert not (tmp_path / f"{VALID_VIDEO_ID}.tmp").exists()

    def test_missing_or_corrupted_cache_returns_none(self, tmp_path: Path) -> None:
        assert load_cached_prompt_package(VALID_VIDEO_ID, tmp_path) is None
        (tmp_path / f"{VALID_VIDEO_ID}.json").write_text("not json", encoding="utf-8")
        assert load_cached_prompt_package(VALID_VIDEO_ID, tmp_path) is None

    def test_write_error_raises_cache_exception(self, tmp_path: Path) -> None:
        package = compile_prompt_package(_spec())
        blocked_target = tmp_path / "not-a-directory"
        blocked_target.write_text("block", encoding="utf-8")
        with pytest.raises(PromptPackageCacheError):
            save_prompt_package(package, blocked_target)


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------


class TestExceptionHierarchy:
    def test_invalid_spec_error_is_prompt_compiler_error(self) -> None:
        from prompt_compiler import PromptCompilerError

        assert issubclass(InvalidRedesignSpecError, PromptCompilerError)

    def test_cache_error_is_prompt_compiler_error(self) -> None:
        from prompt_compiler import PromptCompilerError

        assert issubclass(PromptPackageCacheError, PromptCompilerError)
